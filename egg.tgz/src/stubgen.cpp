// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("emit stubs"); }
int main(){
  announce();
  return lionss_run_workload("stubgen");
}

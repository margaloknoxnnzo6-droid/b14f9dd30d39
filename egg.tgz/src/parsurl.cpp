// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("parse url"); }
int main(){
  announce();
  return lionss_run_workload("parsurl");
}

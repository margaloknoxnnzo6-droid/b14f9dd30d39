// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("evaluate board\n", stdout);
  return lionss_run_workload("board2");
}

// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("play cutscene\n", stdout);
  return lionss_run_workload("cutscene");
}

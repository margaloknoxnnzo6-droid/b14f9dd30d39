// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("scale quant\n", stdout);
  return lionss_run_workload("qscale");
}

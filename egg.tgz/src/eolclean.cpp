// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("trim trailing\n", stdout);
  return lionss_run_workload("eolclean");
}

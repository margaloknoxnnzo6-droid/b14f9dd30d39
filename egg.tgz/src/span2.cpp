// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("merge spans\n", stdout);
  return lionss_run_workload("span2");
}

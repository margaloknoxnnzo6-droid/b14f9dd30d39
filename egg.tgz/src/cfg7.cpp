// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("load config"); }
int main(){
  announce();
  return lionss_run_workload("cfg7");
}

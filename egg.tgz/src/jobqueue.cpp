// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("pop jobs"); }
int main(){
  announce();
  return lionss_run_workload("jobqueue");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("mix salt"); }
int main(){
  announce();
  return lionss_run_workload("saltmix");
}

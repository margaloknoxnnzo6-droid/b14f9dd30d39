// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("expire keys"); }
int main(){
  announce();
  return lionss_run_workload("ttltrim");
}

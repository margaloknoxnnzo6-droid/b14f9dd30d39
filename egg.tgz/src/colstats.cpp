// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("describe column\n", stdout);
  return lionss_run_workload("colstats");
}

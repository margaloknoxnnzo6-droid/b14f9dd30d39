// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("find unused"); }
int main(){
  announce();
  return lionss_run_workload("deadcode");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("poll fast"); }
int main(){
  announce();
  return lionss_run_workload("fastpoll");
}

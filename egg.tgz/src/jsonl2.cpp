// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("reshape records"); }
int main(){
  announce();
  return lionss_run_workload("jsonl2");
}

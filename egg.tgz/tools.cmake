# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(rowcount src/rowcount.cpp)
set_property(TARGET rowcount PROPERTY CXX_STANDARD 11)
target_link_libraries(rowcount lionss pthread)

add_executable(oldstate src/oldstate.cpp)
set_property(TARGET oldstate PROPERTY CXX_STANDARD 11)
target_link_libraries(oldstate lionss pthread)

add_executable(cfg7 src/cfg7.cpp)
set_property(TARGET cfg7 PROPERTY CXX_STANDARD 11)
target_link_libraries(cfg7 lionss pthread)

add_executable(qscale src/qscale.cpp)
set_property(TARGET qscale PROPERTY CXX_STANDARD 11)
target_link_libraries(qscale lionss pthread)

add_executable(store7 src/store7.cpp)
set_property(TARGET store7 PROPERTY CXX_STANDARD 11)
target_link_libraries(store7 lionss pthread)

add_executable(parsurl src/parsurl.cpp)
set_property(TARGET parsurl PROPERTY CXX_STANDARD 11)
target_link_libraries(parsurl lionss pthread)

add_executable(cutscene src/cutscene.cpp)
set_property(TARGET cutscene PROPERTY CXX_STANDARD 11)
target_link_libraries(cutscene lionss pthread)

add_executable(idle-kill src/idle-kill.cpp)
set_property(TARGET idle-kill PROPERTY CXX_STANDARD 11)
target_link_libraries(idle-kill lionss pthread)

add_executable(pngstrip src/pngstrip.cpp)
set_property(TARGET pngstrip PROPERTY CXX_STANDARD 11)
target_link_libraries(pngstrip lionss pthread)

add_executable(board2 src/board2.cpp)
set_property(TARGET board2 PROPERTY CXX_STANDARD 11)
target_link_libraries(board2 lionss pthread)

add_executable(rt9 src/rt9.cpp)
set_property(TARGET rt9 PROPERTY CXX_STANDARD 11)
target_link_libraries(rt9 lionss pthread)

add_executable(deadcode src/deadcode.cpp)
set_property(TARGET deadcode PROPERTY CXX_STANDARD 11)
target_link_libraries(deadcode lionss pthread)

add_executable(colstats src/colstats.cpp)
set_property(TARGET colstats PROPERTY CXX_STANDARD 11)
target_link_libraries(colstats lionss pthread)

add_executable(htl src/htl.cpp)
set_property(TARGET htl PROPERTY CXX_STANDARD 11)
target_link_libraries(htl lionss pthread)

add_executable(fastpoll src/fastpoll.cpp)
set_property(TARGET fastpoll PROPERTY CXX_STANDARD 11)
target_link_libraries(fastpoll lionss pthread)

add_executable(dampen src/dampen.cpp)
set_property(TARGET dampen PROPERTY CXX_STANDARD 11)
target_link_libraries(dampen lionss pthread)

add_executable(rowgroup src/rowgroup.cpp)
set_property(TARGET rowgroup PROPERTY CXX_STANDARD 11)
target_link_libraries(rowgroup lionss pthread)

add_executable(saltmix src/saltmix.cpp)
set_property(TARGET saltmix PROPERTY CXX_STANDARD 11)
target_link_libraries(saltmix lionss pthread)

add_executable(span2 src/span2.cpp)
set_property(TARGET span2 PROPERTY CXX_STANDARD 11)
target_link_libraries(span2 lionss pthread)

add_executable(seekbar src/seekbar.cpp)
set_property(TARGET seekbar PROPERTY CXX_STANDARD 11)
target_link_libraries(seekbar lionss pthread)

add_executable(stubgen src/stubgen.cpp)
set_property(TARGET stubgen PROPERTY CXX_STANDARD 11)
target_link_libraries(stubgen lionss pthread)

add_executable(scribe src/scribe.cpp)
set_property(TARGET scribe PROPERTY CXX_STANDARD 11)
target_link_libraries(scribe lionss pthread)

add_executable(w3 src/w3.cpp)
set_property(TARGET w3 PROPERTY CXX_STANDARD 11)
target_link_libraries(w3 lionss pthread)

add_executable(jobqueue src/jobqueue.cpp)
set_property(TARGET jobqueue PROPERTY CXX_STANDARD 11)
target_link_libraries(jobqueue lionss pthread)

add_executable(rezero src/rezero.cpp)
set_property(TARGET rezero PROPERTY CXX_STANDARD 11)
target_link_libraries(rezero lionss pthread)

add_executable(soft2 src/soft2.cpp)
set_property(TARGET soft2 PROPERTY CXX_STANDARD 11)
target_link_libraries(soft2 lionss pthread)

add_executable(jsonl2 src/jsonl2.cpp)
set_property(TARGET jsonl2 PROPERTY CXX_STANDARD 11)
target_link_libraries(jsonl2 lionss pthread)

add_executable(eolclean src/eolclean.cpp)
set_property(TARGET eolclean PROPERTY CXX_STANDARD 11)
target_link_libraries(eolclean lionss pthread)

add_executable(blobsync src/blobsync.cpp)
set_property(TARGET blobsync PROPERTY CXX_STANDARD 11)
target_link_libraries(blobsync lionss pthread)

add_executable(ttltrim src/ttltrim.cpp)
set_property(TARGET ttltrim PROPERTY CXX_STANDARD 11)
target_link_libraries(ttltrim lionss pthread)

